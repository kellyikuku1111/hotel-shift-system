<?php
function getShiftStatus(mysqli $conn, int $user_id): array {
    $now = new DateTime();

    // Default values
    $nextShiftMsg = "✅ You have no upcoming shifts scheduled.";
    $offDays = [];

    // --- Next shift ---
    $sql = "SELECT a.work_date, s.start_time, s.end_time, s.name AS shift_name
            FROM assignments a
            JOIN shifts s ON a.shift_id = s.id
            WHERE a.user_id = ?
              AND CONCAT(a.work_date, ' ', s.start_time) >= NOW()
            ORDER BY a.work_date, s.start_time
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $shiftStart = new DateTime($row['work_date'] . ' ' . $row['start_time']);
        $shiftEnd   = new DateTime($row['work_date'] . ' ' . $row['end_time']);

        if ($now >= $shiftStart && $now <= $shiftEnd) {
            $nextShiftMsg = "⏱ You are currently on shift ({$row['shift_name']}) until " . $shiftEnd->format("g:i A");
        } elseif ($now < $shiftStart) {
            $interval = $now->diff($shiftStart);
            $timeLeft = $interval->format('%a days %h hours %i minutes');
            $nextShiftMsg = "🛋 You are off duty. Your next shift ({$row['shift_name']}) starts on " .
                            $shiftStart->format("l, F j, Y g:i A") . " (in $timeLeft).";
        }
    }

    // --- Off days this week ---
    $weekStart = (clone $now)->modify('monday this week')->setTime(0,0);
    $weekEnd   = (clone $weekStart)->modify('+6 days');

    $sql2 = "SELECT DISTINCT work_date FROM assignments WHERE user_id=? AND work_date BETWEEN ? AND ?";
    $stmt2 = $conn->prepare($sql2);
    $startStr = $weekStart->format('Y-m-d');
    $endStr   = $weekEnd->format('Y-m-d');
    $stmt2->bind_param("iss", $user_id, $startStr, $endStr);
    $stmt2->execute();
    $res2 = $stmt2->get_result();

    $assignedDays = [];
    while ($r = $res2->fetch_assoc()) {
        $assignedDays[] = $r['work_date'];
    }

    $period = new DatePeriod($weekStart, new DateInterval('P1D'), $weekEnd->modify('+1 day'));
    foreach ($period as $day) {
        if (!in_array($day->format('Y-m-d'), $assignedDays)) {
            $offDays[] = $day->format('l, F j');
        }
    }

    // ✅ Always return an array
    return [
        'nextShift' => $nextShiftMsg,
        'offDays'   => $offDays
    ];
}
function addNotification($conn, $user_id, $message) {
    $stmt = $conn->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $message);
    $stmt->execute();
}
