<?php
require_once 'config.php'; // Make sure this path is correct

echo "<h2>🔍 Testing Brain B Hotel Shift System</h2>";

// ----------------------
// Test Database Connection
// ----------------------
echo "<h3>🗄️ Database Connection:</h3>";
if ($conn->connect_error) {
    echo "❌ Connection failed: " . $conn->connect_error;
} else {
    echo "✅ Connected to database successfully!";
}

// ----------------------
// Test SMTP Email
// ----------------------
echo "<h3>📧 Sending Test Email:</h3>";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; // Make sure PHPMailer is installed via Composer

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = $smtp_host;
    $mail->SMTPAuth   = true;
    $mail->Username   = $smtp_user;
    $mail->Password   = $smtp_pass;
    $mail->SMTPSecure = $smtp_secure;
    $mail->Port       = $smtp_port;

    $mail->setFrom($smtp_from, $smtp_from_name);
    $mail->addAddress($smtp_user); // Send to yourself

    $mail->Subject = 'Test Email from Brain B Hotel Shift System';
    $mail->Body    = '✅ This is a test email sent using SMTP settings.';

    $mail->send();
    echo "✅ Test email sent successfully!";
} catch (Exception $e) {
    echo "❌ Email could not be sent. Error: {$mail->ErrorInfo}";
}
?>
