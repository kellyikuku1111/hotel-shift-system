<?php
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../auth/guard.php';
requireRole(['staff','admin','manager']);
require_once __DIR__ . '/../config.php';

$user_id = $_SESSION['user_id'];

$sql = "SELECT a.work_date, s.name AS shift, s.start_time, s.end_time
        FROM assignments a
        JOIN shifts s ON a.shift_id = s.id
        WHERE a.user_id = ?
        ORDER BY a.work_date, s.start_time";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Shifts</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        body {display:flex;justify-content:center;align-items:flex-start;min-height:100vh;background:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;padding:40px;}
        .box {background:#fff;padding:30px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);width:90%;max-width:800px;}
        h2 {margin-top:0;margin-bottom:20px;color:#2c3e50;text-align:center;}
        .back-btn {display:inline-block;margin-bottom:15px;padding:8px 14px;background:#3498db;color:#fff;border-radius:4px;text-decoration:none;font-size:14px;}
        .back-btn:hover {background:#2980b9;}
        table {width:100%;border-collapse:collapse;margin-top:20px;}
        th, td {padding:12px 10px;border:1px solid #ddd;text-align:left;}
        th {background:#3498db;color:#fff;font-weight:600;}
        tr:nth-child(even) {background:#f9f9f9;}
        .empty {text-align:center;color:#777;font-style:italic;}
    </style>
</head>
<body>
    <div class="box">
        <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
        <h2>My Shifts</h2>
    <?php
$status = getShiftStatus($conn, $_SESSION['user_id']);
echo "<p>{$status['nextShift']}</p>";

if (!empty($status['offDays'])) {
    echo "<p>📅 Your off‑days this week: " . implode(', ', $status['offDays']) . "</p>";
}
?>

        <table>
            <tr>
                <th>Date</th>
                <th>Shift</th>
                <th>Start</th>
                <th>End</th>
            </tr>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['work_date']) ?></td>
                        <td><?= htmlspecialchars($row['shift']) ?></td>
                        <td><?= htmlspecialchars($row['start_time']) ?></td>
                        <td><?= htmlspecialchars($row['end_time']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4" class="empty">No shifts assigned yet.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
