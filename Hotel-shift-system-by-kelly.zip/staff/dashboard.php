<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['staff','manager','admin']);
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../helpers.php';

$status = getShiftStatus($conn, $_SESSION['user_id']);

// Fetch notifications
$uid = $_SESSION['user_id'];
$noti = $conn->prepare("SELECT * FROM notifications WHERE user_id=? AND is_read=0 ORDER BY created_at DESC LIMIT 5");
$noti->bind_param("i", $uid);
$noti->execute();
$notifications = $noti->get_result();

// Handle mark all as read
if (isset($_POST['mark_read'])) {
    $conn->query("UPDATE notifications SET is_read=1 WHERE user_id=$uid");
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Staff Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">Hotel Shifts</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="../calendar.php">Calendar</a></li>
        <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
        <li class="nav-item"><a class="btn btn-danger ms-2" href="../auth/logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container my-4">
  <h2 class="mb-4">Welcome, <?= htmlspecialchars($_SESSION['name']) ?></h2>

  <!-- Notifications -->
  <div class="card mb-4 shadow-sm">
    <div class="card-header bg-primary text-white">
      🔔 Notifications
    </div>
    <div class="card-body">
      <?php if ($notifications->num_rows > 0): ?>
        <ul class="list-group mb-3">
          <?php while ($n = $notifications->fetch_assoc()): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
              <?= htmlspecialchars($n['message']) ?>
              <small class="text-muted"><?= $n['created_at'] ?></small>
            </li>
          <?php endwhile; ?>
        </ul>
        <form method="post">
          <button type="submit" name="mark_read" class="btn btn-sm btn-outline-secondary">Mark all as read</button>
        </form>
      <?php else: ?>
        <p class="text-muted mb-0">No new notifications.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Quick Actions -->
  <div class="row mb-4">
    <div class="col-md-3">
      <div class="card shadow-sm text-center">
        <div class="card-body">
          <h5 class="card-title">📝 Request Leave</h5>
          <a href="leave_request.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm text-center">
        <div class="card-body">
          <h5 class="card-title">📅 View Calendar</h5>
          <a href="../calendar.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm text-center">
        <div class="card-body">
          <h5 class="card-title">🔄 Request Swap</h5>
          <a href="request_swap.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="card shadow-sm text-center">
        <div class="card-body">
          <h5 class="card-title">👤 My Profile</h5>
          <a href="profile.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Next Shift Banner -->
  <div class="card shadow-sm mb-4">
    <div class="card-header bg-success text-white">
      Next Shift
    </div>
    <div class="card-body">
      <p class="fs-5"><?= $status['nextShift'] ?></p>
      <?php if (!empty($status['offDays'])): ?>
        <p class="text-muted">📅 Off days this week: <?= implode(', ', $status['offDays']) ?></p>
      <?php endif; ?>
    </div>
  </div>

  <!-- My Shifts -->
  <a href="my_shifts.php" class="btn btn-outline-primary">View My Shifts</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
