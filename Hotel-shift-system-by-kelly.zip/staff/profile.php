<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['staff','manager','admin']);
require_once __DIR__ . '/../config.php';

$msg = '';
$user_id = $_SESSION['user_id'];

// Fetch current user info
$stmt = $conn->prepare("SELECT name, email, password_hash FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $currentPass = $_POST['current_password'] ?? '';
    $newPass     = $_POST['new_password'] ?? '';
    $confirmPass = $_POST['confirm_password'] ?? '';

    // Update name/email
    $upd = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
    $upd->bind_param("ssi", $name, $email, $user_id);
    $upd->execute();

    // Update password if provided
    if ($newPass) {
        if (!password_verify($currentPass, $user['password_hash'])) {
            $msg = "❌ Current password is incorrect.";
        } elseif ($newPass !== $confirmPass) {
            $msg = "❌ New passwords do not match.";
        } elseif (strlen($newPass) < 6) {
            $msg = "❌ New password must be at least 6 characters.";
        } else {
            $hash = password_hash($newPass, PASSWORD_DEFAULT);
            $upd2 = $conn->prepare("UPDATE users SET password_hash=? WHERE id=?");
            $upd2->bind_param("si", $hash, $user_id);
            $upd2->execute();
            $msg = "✅ Profile updated and password changed.";
            // Refresh stored hash
            $user['password_hash'] = $hash;
        }
    } else {
        $msg = "✅ Profile updated successfully.";
    }

    // Refresh displayed info
    $user['name'] = $name;
    $user['email'] = $email;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>My Profile</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>My Profile</h2>
  <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
  <form method="POST">
    <label>Name:</label>
    <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>

    <label>Email:</label>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

    <hr>
    <p><strong>Change Password (optional)</strong></p>
    <input type="password" name="current_password" placeholder="Current Password">
    <input type="password" name="new_password" placeholder="New Password">
    <input type="password" name="confirm_password" placeholder="Confirm New Password">

    <button type="submit">Save Changes</button>
  </form>
</div>
</body>
</html>
