<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['staff','manager','admin']);
require_once __DIR__ . '/../config.php';

$msg = '';
$user_id = $_SESSION['user_id'];

// Fetch staff's own assignments
$myShifts = $conn->prepare("
    SELECT a.id, s.name AS shift_name, a.work_date, s.start_time, s.end_time
    FROM assignments a
    JOIN shifts s ON a.shift_id = s.id
    WHERE a.user_id=? ORDER BY a.work_date DESC
");
$myShifts->bind_param("i", $user_id);
$myShifts->execute();
$myShiftsRes = $myShifts->get_result();

// Fetch other staff (potential swap partners)
$others = $conn->query("SELECT id, name FROM users WHERE role='staff' AND id<>$user_id ORDER BY name");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $assignment_id = $_POST['assignment_id'];
    $target_id = $_POST['target_id'];

    $stmt = $conn->prepare("INSERT INTO shift_swaps (requester_id, target_id, assignment_id) VALUES (?,?,?)");
    $stmt->bind_param("iii", $user_id, $target_id, $assignment_id);
    if ($stmt->execute()) {
        $msg = "✅ Swap request submitted.";
    } else {
        $msg = "❌ Error: " . $stmt->error;
    }
}

// Fetch user’s swap requests
$reqs = $conn->prepare("
    SELECT ss.*, u.name AS target_name, s.name AS shift_name, a.work_date
    FROM shift_swaps ss
    JOIN users u ON ss.target_id=u.id
    JOIN assignments a ON ss.assignment_id=a.id
    JOIN shifts s ON a.shift_id=s.id
    WHERE ss.requester_id=? ORDER BY ss.created_at DESC
");
$reqs->bind_param("i", $user_id);
$reqs->execute();
$swapRequests = $reqs->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Request Shift Swap</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>Request Shift Swap</h2>
  <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>

  <form method="POST">
    <label>My Shift:</label>
    <select name="assignment_id" required>
      <option value="">Select one of your shifts</option>
      <?php while ($row = $myShiftsRes->fetch_assoc()): ?>
        <option value="<?= $row['id'] ?>">
          <?= htmlspecialchars($row['shift_name']) ?> on <?= $row['work_date'] ?> (<?= $row['start_time'] ?>–<?= $row['end_time'] ?>)
        </option>
      <?php endwhile; ?>
    </select>

    <label>Swap With:</label>
    <select name="target_id" required>
      <option value="">Select colleague</option>
      <?php while ($o = $others->fetch_assoc()): ?>
        <option value="<?= $o['id'] ?>"><?= htmlspecialchars($o['name']) ?></option>
      <?php endwhile; ?>
    </select>

    <button type="submit">Submit Swap Request</button>
  </form>

  <h3>My Swap Requests</h3>
  <table>
    <tr><th>Shift</th><th>Date</th><th>Target</th><th>Status</th></tr>
    <?php while ($r = $swapRequests->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($r['shift_name']) ?></td>
        <td><?= htmlspecialchars($r['work_date']) ?></td>
        <td><?= htmlspecialchars($r['target_name']) ?></td>
        <td><?= htmlspecialchars($r['status']) ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
</body>
</html>
