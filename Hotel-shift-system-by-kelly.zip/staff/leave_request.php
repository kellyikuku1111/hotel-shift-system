<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['staff','manager','admin']);
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../helpers.php'; // for addNotification()

$msg = '';
$user_id = $_SESSION['user_id'];

// Handle new leave request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $start  = $_POST['start_date'];
    $end    = $_POST['end_date'];
    $reason = trim($_POST['reason']);

    if ($start > $end) {
        $msg = "❌ End date cannot be before start date.";
    } else {
        $stmt = $conn->prepare("INSERT INTO leave_requests (user_id, start_date, end_date, reason) VALUES (?,?,?,?)");
        $stmt->bind_param("isss", $user_id, $start, $end, $reason);
        if ($stmt->execute()) {
            $msg = "✅ Leave request submitted.";

            // 🔔 Notify all admins/managers
            $admins = $conn->query("SELECT id, name FROM users WHERE role IN ('admin','manager')");
            while ($a = $admins->fetch_assoc()) {
                addNotification(
                    $conn,
                    $a['id'],
                    "📩 New leave request submitted by staff ID {$user_id} from $start to $end."
                );
            }
        } else {
            $msg = "❌ Error: " . $stmt->error;
        }
    }
}

// Fetch this user’s leave requests
$res = $conn->prepare("SELECT * FROM leave_requests WHERE user_id=? ORDER BY created_at DESC");
$res->bind_param("i", $user_id);
$res->execute();
$requests = $res->get_result();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Request Leave</title>
  <link rel="stylesheet" href="../style.css">
  <style>
    table { width:100%; border-collapse: collapse; margin-top:20px; }
    th, td { border:1px solid #ccc; padding:8px; text-align:left; }
    th { background:#f4f4f4; }
    .message { margin:10px 0; font-weight:bold; }
    textarea { width:100%; padding:8px; }
  </style>
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>Request Leave</h2>
  <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>

  <form method="POST">
    <label>Start Date:</label>
    <input type="date" name="start_date" required>

    <label>End Date:</label>
    <input type="date" name="end_date" required>

    <label>Reason:</label>
    <textarea name="reason" rows="3"></textarea>

    <button type="submit">Submit Request</button>
  </form>

  <h3>My Leave Requests</h3>
  <table>
    <tr>
      <th>Start</th>
      <th>End</th>
      <th>Reason</th>
      <th>Status</th>
      <th>Requested On</th>
    </tr>
    <?php while ($row = $requests->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['start_date']) ?></td>
        <td><?= htmlspecialchars($row['end_date']) ?></td>
        <td><?= htmlspecialchars($row['reason']) ?></td>
        <td><?= htmlspecialchars($row['status']) ?></td>
        <td><?= htmlspecialchars($row['created_at']) ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
</body>
</html>
