<?php
require_once __DIR__ . '/../auth/guard.php';
require_once __DIR__ . '/../config.php';

// Optional: restrict viewing to all roles
requireRole(['admin','manager','staff']);

$sql = "SELECT a.work_date, u.name AS staff, s.name AS shift, s.start_time, s.end_time
        FROM assignments a
        JOIN users u ON a.user_id = u.id
        JOIN shifts s ON a.shift_id = s.id
        ORDER BY a.work_date, s.start_time";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Weekly Schedule</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        body {display:flex;justify-content:center;align-items:flex-start;min-height:100vh;background:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;padding:40px;}
        .box {background:#fff;padding:30px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);width:90%;max-width:900px;}
        h2 {margin-top:0;margin-bottom:20px;color:#2c3e50;text-align:center;}
        .back-btn {display:inline-block;margin-bottom:15px;padding:8px 14px;background:#3498db;color:#fff;border-radius:4px;text-decoration:none;font-size:14px;}
        .back-btn:hover {background:#2980b9;}
        table {width:100%;border-collapse:collapse;margin-top:20px;}
        th, td {padding:12px 10px;border:1px solid #ddd;text-align:left;}
        th {background:#3498db;color:#fff;font-weight:600;}
        tr:nth-child(even) {background:#f9f9f9;}
        .empty {text-align:center;color:#777;font-style:italic;}
    </style>
</head>
<body>
    <div class="box">
        <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
        <h2>Weekly Schedule</h2>

        <table>
            <tr>
                <th>Date</th>
                <th>Staff</th>
                <th>Shift</th>
                <th>Start</th>
                <th>End</th>
            </tr>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['work_date']) ?></td>
                        <td><?= htmlspecialchars($row['staff']) ?></td>
                        <td><?= htmlspecialchars($row['shift']) ?></td>
                        <td><?= htmlspecialchars($row['start_time']) ?></td>
                        <td><?= htmlspecialchars($row['end_time']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" class="empty">No shifts assigned yet.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
