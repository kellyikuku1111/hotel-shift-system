<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin','manager']);
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../helpers.php'; // only if you added addNotification()

$msg = '';

// Handle approve/deny actions safely
if (isset($_GET['id'], $_GET['action'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];

    if (in_array($action, ['approved','denied'])) {
        // Fetch request details for notifications
        $stmt = $conn->prepare("SELECT user_id, start_date, end_date FROM leave_requests WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $req = $stmt->get_result()->fetch_assoc();

        if ($req) {
            $stmt2 = $conn->prepare("UPDATE leave_requests SET status=? WHERE id=?");
            $stmt2->bind_param("si", $action, $id);
            if ($stmt2->execute()) {
                $msg = "✅ Request $action.";

                // Optional: add notification
                if (function_exists('addNotification')) {
                    if ($action === 'approved') {
                        addNotification($conn, $req['user_id'], 
                            "✅ Your leave request from {$req['start_date']} to {$req['end_date']} has been approved.");
                    } else {
                        addNotification($conn, $req['user_id'], 
                            "❌ Your leave request from {$req['start_date']} to {$req['end_date']} has been denied.");
                    }
                }
            } else {
                $msg = "❌ Error: " . $stmt2->error;
            }
        }
    }
}

// Fetch all leave requests
$res = $conn->query("
    SELECT lr.*, u.name 
    FROM leave_requests lr 
    JOIN users u ON lr.user_id=u.id 
    ORDER BY lr.created_at DESC
");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Leave Requests</title>
  <link rel="stylesheet" href="../style.css">
  <style>
    table { width:100%; border-collapse: collapse; margin-top:20px; }
    th, td { border:1px solid #ccc; padding:8px; text-align:left; }
    th { background:#f4f4f4; }
    .btn { padding:6px 12px; border-radius:4px; text-decoration:none; margin-right:5px; }
    .btn:hover { opacity:0.9; }
    .delete { background:#e74c3c; color:#fff; }
    .delete:hover { background:#c0392b; }
    .approve { background:#27ae60; color:#fff; }
    .approve:hover { background:#1e8449; }
    .message { margin:10px 0; font-weight:bold; }
  </style>
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>Leave Requests</h2>
  <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
  <table>
    <tr>
      <th>Staff</th>
      <th>Start</th>
      <th>End</th>
      <th>Reason</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
    <?php while ($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['start_date']) ?></td>
        <td><?= htmlspecialchars($row['end_date']) ?></td>
        <td><?= htmlspecialchars($row['reason']) ?></td>
        <td><?= htmlspecialchars($row['status']) ?></td>
        <td>
          <?php if ($row['status'] === 'pending'): ?>
            <a href="?id=<?= $row['id'] ?>&action=approved" class="btn approve">Approve</a>
            <a href="?id=<?= $row['id'] ?>&action=denied" class="btn delete">Deny</a>
          <?php else: ?>
            —
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
</body>
</html>
