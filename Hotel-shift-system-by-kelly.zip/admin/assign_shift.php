<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin','manager']);
require_once __DIR__ . '/../config.php';

$msg = '';

// Fetch users and shifts
$users = $conn->query("SELECT id, name FROM users WHERE role='staff' ORDER BY name");
$shifts = $conn->query("SELECT id, name, start_time, end_time FROM shifts ORDER BY start_time");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_POST['user_id'];
    $shift_id = $_POST['shift_id'];
    $date = $_POST['work_date'];

    // Check if staff is on approved leave
    $checkLeave = $conn->prepare("
        SELECT COUNT(*) AS c 
        FROM leave_requests 
        WHERE user_id=? 
          AND status='approved' 
          AND ? BETWEEN start_date AND end_date
    ");
    $checkLeave->bind_param("is", $user_id, $date);
    $checkLeave->execute();
    $leaveCount = $checkLeave->get_result()->fetch_assoc()['c'];

    if ($leaveCount > 0) {
        $msg = "❌ Cannot assign shift — staff is on approved leave for this date.";
    } else {
        $stmt = $conn->prepare("INSERT INTO assignments (user_id, shift_id, work_date) VALUES (?,?,?)");
        $stmt->bind_param("iis", $user_id, $shift_id, $date);
        if ($stmt->execute()) {
            $msg = "✅ Shift assigned successfully.";
        } else {
            $msg = "❌ Error: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Assign Shift</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>Assign Shift</h2>
  <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
  <form method="POST">
    <label>Staff:</label>
    <select name="user_id" required>
      <option value="">Select Staff</option>
      <?php while ($u = $users->fetch_assoc()): ?>
        <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
      <?php endwhile; ?>
    </select>

    <label>Shift:</label>
    <select name="shift_id" required>
      <option value="">Select Shift</option>
      <?php while ($s = $shifts->fetch_assoc()): ?>
        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (<?= $s['start_time'] ?>–<?= $s['end_time'] ?>)</option>
      <?php endwhile; ?>
    </select>

    <label>Date:</label>
    <input type="date" name="work_date" required>

    <button type="submit">Assign</button>
  </form>
</div>
</body>
</html>
