<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin','manager']);
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../helpers.php'; // optional if you use addNotification()

$msg = '';

// Handle approval/denial safely (avoid undefined $action)
if (isset($_GET['id'], $_GET['action'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];

    // Fetch swap request details
    $stmt = $conn->prepare("
        SELECT ss.*, a.user_id AS current_user, a.shift_id, a.work_date
        FROM shift_swaps ss
        JOIN assignments a ON ss.assignment_id=a.id
        WHERE ss.id=?
    ");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $swap = $stmt->get_result()->fetch_assoc();

    if ($swap && $swap['status'] === 'pending') {
        if ($action === 'approved') {
            // Reassign the assignment to target user
            $upd = $conn->prepare("UPDATE assignments SET user_id=? WHERE id=?");
            $upd->bind_param("ii", $swap['target_id'], $swap['assignment_id']);
            if ($upd->execute()) {
                // Mark swap approved
                $upd2 = $conn->prepare("UPDATE shift_swaps SET status='approved' WHERE id=?");
                $upd2->bind_param("i", $id);
                $upd2->execute();
                $msg = "✅ Swap approved. Shift reassigned.";

                // Optional notifications
                if (function_exists('addNotification')) {
                    addNotification($conn, $swap['requester_id'], "✅ Your swap request was approved. Shift reassigned.");
                    addNotification($conn, $swap['target_id'], "🔄 You have been assigned a new shift via swap.");
                }
            } else {
                $msg = "❌ Error updating assignment.";
            }
        } elseif ($action === 'denied') {
            $upd = $conn->prepare("UPDATE shift_swaps SET status='denied' WHERE id=?");
            $upd->bind_param("i", $id);
            $upd->execute();
            $msg = "❌ Swap denied.";

            if (function_exists('addNotification')) {
                addNotification($conn, $swap['requester_id'], "❌ Your swap request was denied.");
            }
        }
    }
}

// Fetch all swap requests
$res = $conn->query("
    SELECT ss.*, r.name AS requester_name, t.name AS target_name, s.name AS shift_name, a.work_date
    FROM shift_swaps ss
    JOIN users r ON ss.requester_id=r.id
    JOIN users t ON ss.target_id=t.id
    JOIN assignments a ON ss.assignment_id=a.id
    JOIN shifts s ON a.shift_id=s.id
    ORDER BY ss.created_at DESC
");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Shift Swap Requests</title>
  <link rel="stylesheet" href="../style.css">
  <style>
    table { width:100%; border-collapse: collapse; margin-top:20px; background:#fff; }
    th, td { border:1px solid #ddd; padding:8px; text-align:left; }
    th { background:#f4f4f4; }
    .btn { padding:6px 12px; border-radius:4px; text-decoration:none; margin-right:5px; display:inline-block; }
    .btn:hover { opacity:0.9; }
    .approve { background:#27ae60; color:#fff; }
    .approve:hover { background:#1e8449; }
    .deny { background:#e74c3c; color:#fff; }
    .deny:hover { background:#c0392b; }
    .message { margin:10px 0; font-weight:bold; }
    .card-container { display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:20px; margin:20px 0; }
    .card { background:#fff; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.1); text-align:center; padding:20px; }
    .card a { text-decoration:none; color:inherit; display:block; }
    .card h3 { margin:0 0 10px; color:#3498db; }
    .card p { font-size:0.9em; color:#555; }
    .card:hover { transform: translateY(-3px); box-shadow:0 4px 12px rgba(0,0,0,0.15); transition: all .2s; }
  </style>
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>Shift Swap Requests</h2>
  <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>

  <div class="card-container">
    <div class="card">
      <a href="shift_list.php">
        <h3>⚙️ Manage Shifts</h3>
        <p>Create and edit shift templates.</p>
      </a>
    </div>
    <div class="card">
      <a href="leave_requests.php">
        <h3>📝 Manage Leave Requests</h3>
        <p>Approve or deny leave applications.</p>
      </a>
    </div>
    <div class="card">
      <a href="assign_shift.php">
        <h3>📌 Assign Shift</h3>
        <p>Assign staff to available shifts.</p>
      </a>
    </div>
    <div class="card">
      <a href="../calendar.php">
        <h3>📅 View Calendar</h3>
        <p>See all scheduled shifts and leave.</p>
      </a>
    </div>
  </div>

  <table>
    <tr><th>Requester</th><th>Target</th><th>Shift</th><th>Date</th><th>Status</th><th>Action</th></tr>
    <?php while ($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['requester_name']) ?></td>
        <td><?= htmlspecialchars($row['target_name']) ?></td>
        <td><?= htmlspecialchars($row['shift_name']) ?></td>
        <td><?= htmlspecialchars($row['work_date']) ?></td>
        <td><?= htmlspecialchars($row['status']) ?></td>
        <td>
          <?php if ($row['status'] === 'pending'): ?>
            <a href="?id=<?= $row['id'] ?>&action=approved" class="btn approve">Approve</a>
            <a href="?id=<?= $row['id'] ?>&action=denied" class="btn deny">Deny</a>
          <?php else: ?>
            —
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
</body>
</html>
