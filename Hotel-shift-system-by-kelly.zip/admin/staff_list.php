<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin']);
require_once __DIR__ . '/../config.php';

$msg = '';

// Handle delete request
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    if ($id === $_SESSION['user_id']) {
        $msg = "❌ You cannot delete your own account.";
    } else {
        $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $msg = "✅ User deleted successfully.";
        } else {
            $msg = "❌ Error deleting user: " . $stmt->error;
        }
    }
}

// Fetch all users
$res = $conn->query("SELECT id, name, email, role FROM users ORDER BY role, name");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Staff</title>
  <style>
    body {font-family:Segoe UI,Arial,sans-serif;background:#f4f6f9;padding:40px;}
    .container {max-width:900px;margin:auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.1);}
    table {width:100%;border-collapse:collapse;margin-top:20px;}
    th, td {padding:12px;border-bottom:1px solid #ddd;text-align:left;}
    th {background:#3498db;color:#fff;}
    .btn {padding:6px 12px;border-radius:4px;text-decoration:none;color:#fff;}
    .delete {background:#e74c3c;}
    .delete:hover {background:#c0392b;}
    .back-btn {display:inline-block;margin-bottom:15px;padding:8px 14px;background:#3498db;color:#fff;border-radius:4px;text-decoration:none;}
    .message {margin-bottom:15px;font-size:14px;}
  </style>
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>Manage Staff</h2>
  <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
  <table>
    <tr><th>Name</th><th>Email</th><th>Role</th><th>Action</th></tr>
    <?php while ($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['email']) ?></td>
        <td><?= htmlspecialchars($row['role']) ?></td>
        <td>
          <a href="?delete=<?= $row['id'] ?>" class="btn delete" onclick="return confirm('Delete this user?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
</body>
</html>
