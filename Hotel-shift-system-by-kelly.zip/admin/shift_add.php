<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin','manager']);
require_once __DIR__ . '/../config.php';
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name']);
    $start = $_POST['start_time'];
    $end   = $_POST['end_time'];

    $stmt = $conn->prepare('INSERT INTO shifts (name,start_time,end_time) VALUES (?,?,?)');
    $stmt->bind_param('sss', $name, $start, $end);
    $msg = $stmt->execute() ? '✅ Shift created.' : ('❌ Error creating shift: ' . $stmt->error);
}
?>
<!DOCTYPE html>
<html>
<head><title>Create Shift</title>
<link rel="stylesheet" href="../style.css">
<style>
  body {display:flex;justify-content:center;align-items:center;height:100vh;background:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;}
  .box {background:#fff;padding:40px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);width:420px;text-align:center;}
  .box h2 {margin-bottom:20px;color:#2c3e50;}
  .box input,.box button {width:100%;padding:14px;margin:10px 0;font-size:16px;border-radius:4px;box-sizing:border-box;}
  .box input {border:1px solid #ccc;}
  .box button {background:#3498db;color:#fff;border:none;cursor:pointer;}
  .box button:hover {background:#2980b9;}
  .message {margin-bottom:15px;font-size:14px;}
  .back-btn {display:inline-block;margin-bottom:15px;padding:8px 14px;background:#3498db;color:#fff;border-radius:4px;text-decoration:none;font-size:14px;}
</style>
</head>
<body>
<div class="box">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>Create Shift</h2>
  <?php if ($msg): ?><p class="message"><?= $msg ?></p><?php endif; ?>
  <form method="POST">
      <input name="name" placeholder="Shift Name" required>
      <input type="time" name="start_time" required>
      <input type="time" name="end_time" required>
      <button type="submit">Save</button>
  </form>
</div>
</body>
</html>
