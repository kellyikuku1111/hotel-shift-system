<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin','manager']);
require_once __DIR__ . '/../config.php';

// Quick stats
$totalUsers = $conn->query("SELECT COUNT(*) AS c FROM users")->fetch_assoc()['c'];
$totalShifts = $conn->query("SELECT COUNT(*) AS c FROM shifts")->fetch_assoc()['c'];
$totalAssignments = $conn->query("SELECT COUNT(*) AS c FROM assignments")->fetch_assoc()['c'];

// Recent assignments
$recent = $conn->query("
    SELECT a.work_date, u.name AS staff, s.name AS shift, s.start_time, s.end_time
    FROM assignments a
    JOIN users u ON a.user_id = u.id
    JOIN shifts s ON a.shift_id = s.id
    ORDER BY a.work_date DESC, s.start_time ASC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php">Hotel Shifts</a>
    <div class="collapse navbar-collapse">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="../calendar.php">Calendar</a></li>
        <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
        <li class="nav-item">
          <a class="btn btn-danger ms-2" href="../auth/logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>


<div class="container my-4">
  <h2 class="mb-4">Welcome, <?= htmlspecialchars($_SESSION['name']) ?></h2>

  <!-- Stats Cards -->
  <div class="row mb-4">
    <div class="col-md-4">
      <div class="card text-center shadow-sm">
        <div class="card-body">
          <h5 class="card-title">👥 Users</h5>
          <h2><?= $totalUsers ?></h2>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-center shadow-sm">
        <div class="card-body">
          <h5 class="card-title">📅 Shift Templates</h5>
          <h2><?= $totalShifts ?></h2>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card text-center shadow-sm">
        <div class="card-body">
          <h5 class="card-title">📌 Assignments</h5>
          <h2><?= $totalAssignments ?></h2>
        </div>
      </div>
    </div>
  </div>

  <!-- Action Cards -->
  <div class="row mb-4">
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">⚙️ Manage Shifts</h5>
          <p class="card-text">Create and edit shift templates.</p>
          <a href="shift_list.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">📝 Leave Requests</h5>
          <p class="card-text">Approve or deny staff leave.</p>
          <a href="leave_requests.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">🔄 Shift Swaps</h5>
          <p class="card-text">Review and approve swap requests.</p>
          <a href="shift_swaps.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
  </div>

  <!-- More Actions -->
  <div class="row mb-4">
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">➕ Add Staff</h5>
          <p class="card-text">Register new staff members.</p>
          <a href="staff_add.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">👥 Manage Staff</h5>
          <p class="card-text">View and edit staff profiles.</p>
          <a href="staff_list.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
    
    <div class="col-md-4">
      <div class="card shadow-sm">
        <div class="card-body text-center">
          <h5 class="card-title">📅 View Calendar</h5>
          <p class="card-text">See all scheduled shifts and leave.</p>
          <a href="../calendar.php" class="btn btn-primary">Open</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Recent Assignments Table -->
  <h3>Recent Assignments</h3>
  <div class="table-responsive">
    <table class="table table-striped table-hover">
      <thead class="table-dark">
        <tr>
          <th>Date</th>
          <th>Staff</th>
          <th>Shift</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $recent->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars(date("M j, Y", strtotime($row['work_date']))) ?></td>
            <td><?= htmlspecialchars($row['staff']) ?></td>
            <td><?= htmlspecialchars($row['shift']) ?></td>
            <td><?= htmlspecialchars($row['start_time']) ?>–<?= htmlspecialchars($row['end_time']) ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>
