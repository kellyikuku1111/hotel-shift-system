<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin','manager']);
require_once __DIR__ . '/../config.php';

// Total staff
$totalStaff = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role='staff'")->fetch_assoc()['c'];

// Total hours scheduled this month
$totalHours = $conn->query("
    SELECT SUM(TIMESTAMPDIFF(HOUR, s.start_time, s.end_time)) AS hours
    FROM assignments a
    JOIN shifts s ON a.shift_id=s.id
    WHERE MONTH(a.work_date)=MONTH(CURDATE()) AND YEAR(a.work_date)=YEAR(CURDATE())
")->fetch_assoc()['hours'];

// Total leave days this month
$totalLeave = $conn->query("
    SELECT SUM(DATEDIFF(end_date, start_date)+1) AS days
    FROM leave_requests
    WHERE status='approved' 
      AND MONTH(start_date)=MONTH(CURDATE()) 
      AND YEAR(start_date)=YEAR(CURDATE())
")->fetch_assoc()['days'];

// Swap stats
$swapStats = $conn->query("SELECT status, COUNT(*) AS c FROM shift_swaps GROUP BY status");
$swaps = [];
while ($row = $swapStats->fetch_assoc()) {
    $swaps[$row['status']] = $row['c'];
}

// Hours per staff (for bar chart)
$res = $conn->query("
    SELECT u.name, SUM(TIMESTAMPDIFF(HOUR, s.start_time, s.end_time)) AS hours
    FROM assignments a
    JOIN users u ON a.user_id=u.id
    JOIN shifts s ON a.shift_id=s.id
    WHERE MONTH(a.work_date)=MONTH(CURDATE()) AND YEAR(a.work_date)=YEAR(CURDATE())
    GROUP BY u.id
");
$staffHours = [];
while ($r = $res->fetch_assoc()) {
    $staffHours[] = $r;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Reports & Analytics</title>
  <link rel="stylesheet" href="../style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {font-family:Segoe UI,Arial,sans-serif;background:#f4f6f9;padding:40px;}
    .container {max-width:1000px;margin:auto;}
    h2 {color:#2c3e50;}
    .stats {display:flex;gap:20px;margin:20px 0;flex-wrap:wrap;}
    .stat {flex:1;min-width:200px;background:#fff;padding:20px;border-radius:8px;
           box-shadow:0 2px 6px rgba(0,0,0,0.1);text-align:center;}
    .stat h2 {margin:0;color:#3498db;}
    canvas {background:#fff;padding:10px;border-radius:8px;margin-bottom:20px;box-shadow:0 2px 6px rgba(0,0,0,0.1);}
    .back-btn {display:inline-block;margin-bottom:20px;text-decoration:none;background:#3498db;color:#fff;
               padding:8px 14px;border-radius:4px;}
    .back-btn:hover {background:#2980b9;}
  </style>
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>📊 Reports & Analytics</h2>

  <div class="stats">
    <div class="stat"><h2><?= $totalStaff ?></h2><p>Total Staff</p></div>
    <div class="stat"><h2><?= $totalHours ?: 0 ?></h2><p>Hours Scheduled (This Month)</p></div>
    <div class="stat"><h2><?= $totalLeave ?: 0 ?></h2><p>Leave Days (This Month)</p></div>
    <div class="stat"><h2><?= $swaps['approved'] ?? 0 ?>/<?= $swaps['denied'] ?? 0 ?></h2><p>Swaps (Approved/Denied)</p></div>
  </div>

  <h3>Hours per Staff (This Month)</h3>
  <canvas id="hoursChart"></canvas>

  <script>
    const ctx = document.getElementById('hoursChart');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: <?= json_encode(array_column($staffHours, 'name')) ?>,
        datasets: [{
          label: 'Hours Worked',
          data: <?= json_encode(array_column($staffHours, 'hours')) ?>,
          backgroundColor: '#3498db'
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
      }
    });
  </script>
</div>
</body>
</html>
