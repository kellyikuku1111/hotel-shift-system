<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin','manager']);
require_once __DIR__ . '/../config.php';

$msg = '';

// Handle delete request
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];

    // Prevent deleting a shift that is already assigned (optional safety)
    $check = $conn->prepare("SELECT COUNT(*) AS c FROM assignments WHERE shift_id=?");
    $check->bind_param("i", $id);
    $check->execute();
    $count = $check->get_result()->fetch_assoc()['c'];

    if ($count > 0) {
        $msg = "❌ Cannot delete shift — it is already assigned to staff.";
    } else {
        $stmt = $conn->prepare("DELETE FROM shifts WHERE id=?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $msg = "✅ Shift deleted successfully.";
        } else {
            $msg = "❌ Error deleting shift: " . $stmt->error;
        }
    }
}

// Fetch all shifts
$res = $conn->query("SELECT id, name, start_time, end_time FROM shifts ORDER BY start_time");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Shifts</title>
  <style>
    body {font-family:Segoe UI,Arial,sans-serif;background:#f4f6f9;padding:40px;}
    .container {max-width:900px;margin:auto;background:#fff;padding:20px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,0.1);}
    table {width:100%;border-collapse:collapse;margin-top:20px;}
    th, td {padding:12px;border-bottom:1px solid #ddd;text-align:left;}
    th {background:#3498db;color:#fff;}
    .btn {padding:6px 12px;border-radius:4px;text-decoration:none;color:#fff;}
    .delete {background:#e74c3c;}
    .delete:hover {background:#c0392b;}
    .back-btn {display:inline-block;margin-bottom:15px;padding:8px 14px;background:#3498db;color:#fff;border-radius:4px;text-decoration:none;}
    .message {margin-bottom:15px;font-size:14px;}
  </style>
</head>
<body>
<div class="container">
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  <h2>Manage Shifts</h2>
  <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
  <table>
    <tr><th>Name</th><th>Start</th><th>End</th><th>Action</th></tr>
    <?php while ($row = $res->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['name']) ?></td>
        <td><?= htmlspecialchars($row['start_time']) ?></td>
        <td><?= htmlspecialchars($row['end_time']) ?></td>
        <td>
          <a href="?delete=<?= $row['id'] ?>" class="btn delete" onclick="return confirm('Delete this shift?')">Delete</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
</body>
</html>
