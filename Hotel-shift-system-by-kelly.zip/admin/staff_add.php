<?php
require_once __DIR__ . '/../auth/guard.php';
requireRole(['admin']);
require_once __DIR__ . '/../config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/PHPMailer/src/Exception.php';
require __DIR__ . '/../vendor/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/../vendor/PHPMailer/src/SMTP.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);
    $role  = $_POST['role'];
    $placeholder_pass = password_hash('changeme123', PASSWORD_DEFAULT);

    $allowed_roles = ['admin','manager','staff'];
    if (!in_array($role, $allowed_roles, true)) {
        $msg = '❌ Invalid role selected.';
    } else {
        $check = $conn->prepare('SELECT id FROM users WHERE email=?');
        $check->bind_param('s', $email);
        $check->execute();
        $res = $check->get_result();

        if ($res->num_rows > 0) {
            $msg = '❌ A user with this email already exists.';
        } else {
            $reset_token = bin2hex(random_bytes(16));
            $reset_expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt = $conn->prepare('INSERT INTO users (name,email,role,password_hash,is_verified,reset_token,reset_expires) VALUES (?,?,?,?,0,?,?)');
            $stmt->bind_param('ssssss', $name, $email, $role, $placeholder_pass, $reset_token, $reset_expires);

            if ($stmt->execute()) {
                $reset_link = $app_base_url . '/auth/reset_password.php?token=' . $reset_token;

                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = $smtp_host;
                    $mail->SMTPAuth = true;
                    $mail->Username = $smtp_user;
                    $mail->Password = $smtp_pass;
                    $mail->SMTPSecure = $smtp_secure;
                    $mail->Port = $smtp_port;

                    $mail->setFrom($smtp_from, $smtp_from_name);
                    $mail->addAddress($email, $name);
                    $mail->isHTML(true);
                    $mail->Subject = "Set Your Password – $app_name";

                    $mail->Body = "
                    <html><body style='font-family:Segoe UI,Arial,sans-serif;background:#f4f6f9;padding:20px;'>
                      <div style='max-width:600px;margin:auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.12);'>
                        <div style='background:#3498db;color:#fff;padding:16px;font-size:18px;font-weight:600;'>
                          $app_name Account
                        </div>
                        <div style='padding:24px;'>
                          <h2 style='margin:0 0 12px 0;color:#2c3e50;'>Hello, ".htmlspecialchars($name)."</h2>
                          <p>You have been added as a <strong>$role</strong>.</p>
                          <p>Click the button below to set your password and activate your account:</p>
                          <p style='text-align:center;'>
                            <a href='$reset_link' style='display:inline-block;background:#3498db;color:#fff;text-decoration:none;padding:12px 20px;border-radius:6px;font-weight:600;'>Set Password</a>
                          </p>
                          <p style='color:#555;font-size:14px;'>This link will expire in 1 hour.</p>
                        </div>
                      </div>
                    </body></html>";
                    $mail->AltBody = "Hello $name,\n\nYou have been added as a $role.\nSet your password: $reset_link\nLink expires in 1 hour.";

                    $mail->send();
                    $msg = "✅ $role added successfully. Reset email sent.";
                } catch (Exception $e) {
                    $msg = "✅ $role added, but email could not be sent. Error: {$mail->ErrorInfo}";
                }
            } else {
                $msg = '❌ Error adding user: ' . $stmt->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add User</title>
    <style>
        body {display:flex;justify-content:center;align-items:center;height:100vh;background:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;}
        .box {background:#fff;padding:40px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);width:420px;text-align:center;}
        .box h2 {margin-bottom:20px;color:#2c3e50;}
        .box input,.box select,.box button {width:100%;padding:14px;margin:10px 0;font-size:16px;border-radius:4px;box-sizing:border-box;}
        .box input,.box select {border:1px solid #ccc;}
        .box button {background:#3498db;color:#fff;border:none;cursor:pointer;}
        .box button:hover {background:#2980b9;}
        .message {margin-bottom:15px;font-size:14px;}
        .back-btn {display:inline-block;margin-bottom:15px;padding:8px 14px;background:#3498db;color:#fff;border-radius:4px;text-decoration:none;font-size:14px;}
    </style>
</head>
<body>
    <div class="box">
        <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
        <h2>Add User</h2>
        <?php if ($msg): ?><p class="message"><?= $msg ?></p><?php endif; ?>
        <form method="POST">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="staff">Staff</option>
                <option value="manager">Manager</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit">Add User</button>
        </form>
    </div>
</body>
</html>
