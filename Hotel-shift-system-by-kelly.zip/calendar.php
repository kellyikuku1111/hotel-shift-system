<?php
require_once __DIR__ . '/auth/guard.php';
require_once __DIR__ . '/config.php';

$user_id = $_SESSION['user_id'];
$role    = $_SESSION['role'] ?? 'staff';

// Decide back link based on role
$backLink = 'staff/dashboard.php';
if ($role === 'admin' || $role === 'manager') {
    $backLink = 'admin/dashboard.php';
}

$events = [];

// If staff → only their shifts and leave
if ($role === 'staff') {
    // Fetch assignments
    $stmt = $conn->prepare("
        SELECT a.work_date, s.name AS shift_name, s.start_time, s.end_time
        FROM assignments a
        JOIN shifts s ON a.shift_id = s.id
        WHERE a.user_id=?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $assignments = $stmt->get_result();

    while ($row = $assignments->fetch_assoc()) {
        $events[] = [
            'title' => $row['shift_name'] . " (" . $row['start_time'] . "–" . $row['end_time'] . ")",
            'start' => $row['work_date'],
            'color' => '#3498db'
        ];
    }

    // Fetch approved leave
    $leave = $conn->prepare("
        SELECT start_date, end_date
        FROM leave_requests
        WHERE user_id=? AND status='approved'
    ");
    $leave->bind_param("i", $user_id);
    $leave->execute();
    $leaves = $leave->get_result();

    while ($l = $leaves->fetch_assoc()) {
        $events[] = [
            'title' => "On Leave",
            'start' => $l['start_date'],
            'end'   => date('Y-m-d', strtotime($l['end_date'] . ' +1 day')), // exclusive end
            'color' => '#e74c3c'
        ];
    }
}

// If admin/manager → show all staff shifts
if ($role === 'admin' || $role === 'manager') {
    $res = $conn->query("
        SELECT a.work_date, u.name AS staff, s.name AS shift_name, s.start_time, s.end_time
        FROM assignments a
        JOIN users u ON a.user_id = u.id
        JOIN shifts s ON a.shift_id = s.id
    ");
    while ($row = $res->fetch_assoc()) {
        $events[] = [
            'title' => $row['staff'] . ": " . $row['shift_name'] . " (" . $row['start_time'] . "–" . $row['end_time'] . ")",
            'start' => $row['work_date'],
            'color' => '#2ecc71'
        ];
    }

    // Show all approved leave
    $res2 = $conn->query("
        SELECT lr.start_date, lr.end_date, u.name AS staff
        FROM leave_requests lr
        JOIN users u ON lr.user_id=u.id
        WHERE lr.status='approved'
    ");
    while ($l = $res2->fetch_assoc()) {
        $events[] = [
            'title' => $l['staff'] . " (On Leave)",
            'start' => $l['start_date'],
            'end'   => date('Y-m-d', strtotime($l['end_date'] . ' +1 day')),
            'color' => '#e74c3c'
        ];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Shift Calendar</title>
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
  <style>
    body { font-family:Segoe UI,Arial,sans-serif; margin:40px; background:#f4f6f9; }
    #calendar { max-width: 1000px; margin:auto; background:#fff; padding:20px; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.1);}
    .back-btn { display:inline-block; margin-bottom:20px; text-decoration:none; background:#3498db; color:#fff; padding:8px 14px; border-radius:4px;}
    .back-btn:hover { background:#2980b9; }
  </style>
</head>
<body>
  <a href="<?= $backLink ?>" class="back-btn">← Back to Dashboard</a>
  <h2 style="text-align:center;">📅 Shift Calendar</h2>
  <div id="calendar"></div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var calendarEl = document.getElementById('calendar');
      var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        events: <?= json_encode($events) ?>
      });
      calendar.render();
    });
  </script>
</body>
</html>
