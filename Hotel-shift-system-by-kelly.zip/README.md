## 🚀 Getting Started (Quick Guide)

Follow these steps to get the Hotel Shift Management System running locally:

### 1. Requirements
- PHP 8.0+  
- MySQL 5.7+ or MariaDB  
- Apache (XAMPP, WAMP, or LAMP recommended)  
- Web browser (Chrome, Edge, Firefox)

---

### 2. Installation
1. **Clone the repository** into your server’s root directory (e.g., `htdocs` for XAMPP):
   ```bash
   git clone https://github.com/yourusername/hotel-shifts.git
Create the database:

Open phpMyAdmin (http://localhost/phpmyadmin).

Create a new database (e.g., hotel_shifts).

Import the SQL file from:

Code
sql/database.sql
Configure database connection:

Open config.php.

Update with your MySQL credentials:

php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "hotel_shifts";
Start Apache & MySQL in XAMPP (or your stack).

Access the system in your browser:

Code
http://localhost/hotel-shifts/
3. Default Roles & Demo Accounts
Use these demo accounts to log in quickly:

Admin

Username: kellyikuku84@gmail.com

Password: Admin@123

Manager

Username: kellyikuku85@gmail.com

Password: 123456

Staff

Username: kellyikuku84@gmail.com

Password: 123456

(You can change or add accounts in the users table.)

4. Next Steps
Log in as Admin to add staff, create shifts, and assign roles.

Log in as Manager to approve/deny leave and swaps.

Log in as Staff to request leave, swap shifts, and view your calendar.

✅ That’s it — you’re up and running in minutes!