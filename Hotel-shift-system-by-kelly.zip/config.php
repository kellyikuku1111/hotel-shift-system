<?php
/**
 * ==========================================================
 *  Brain B Hotel Shift System - Configuration File
 * ==========================================================
 *  - Database connection
 *  - Application settings
 *  - SMTP (email) settings
 *  - URL helper
 * ==========================================================
 */

// ----------------------
// Database Configuration
// ----------------------
$db_host = "sql204.infinityfree.com";
$db_user = "if0_40344331";
$db_pass = "07063910582K";
$db_name = "if0_40344331_hotel_shifts";

// Create DB connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("❌ Database connection failed: " . $conn->connect_error);
}

// ----------------------
// Application Settings
// ----------------------
$app_name     = "Brain B Hotel Shift System";

// ✅ IMPORTANT: adjust this for your environment
// For local development (XAMPP/WAMP):
$app_base_url = "https://hotel-shifts.free.nf";
// For production:
// $app_base_url = "https://kelly-hotel-shift.free.nf.com";

// ----------------------
// Helper Function
// ----------------------
/**
 * Build a full URL from a relative path
 * Example: app_url('auth/reset_password.php')
 */
function app_url(string $path): string {
    return rtrim($GLOBALS['app_base_url'], '/') . '/' . ltrim($path, '/');
}

// ----------------------
// SMTP (Email) Settings
// ----------------------
$smtp_host       = "smtp.gmail.com";
$smtp_user       = "kellyikuku84@gmail.com";  // change to your sender
$smtp_pass       = "pupa baft asyn mzbh";     // use an app password
$smtp_secure     = "tls";                   // 'tls' or 'ssl'
$smtp_port       = 587;                     // 587 for TLS, 465 for SSL
$smtp_from       = "kellyikuku84@gmail.com";  // same as $smtp_user usually
$smtp_from_name  = $app_name;
