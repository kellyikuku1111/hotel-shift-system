<?php
require_once __DIR__ . '/../config.php';
session_start();

$msg   = '';
$valid = false;

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Look up user by token
    $stmt = $conn->prepare('SELECT id, reset_expires FROM users WHERE reset_token=?');
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $res  = $stmt->get_result();
    $user = $res->fetch_assoc();

    if ($user) {
        // Check expiry
        if (strtotime($user['reset_expires']) > time()) {
            $valid = true;

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $pass    = $_POST['password'] ?? '';
                $confirm = $_POST['confirm_password'] ?? '';

                // Basic strength check (optional)
                $minLen = 6;
                if (strlen($pass) < $minLen) {
                    $msg = "❌ Password must be at least $minLen characters.";
                } elseif ($pass !== $confirm) {
                    $msg = '❌ Passwords do not match.';
                } else {
                    $hash = password_hash($pass, PASSWORD_DEFAULT);
                    $upd  = $conn->prepare('UPDATE users 
                                             SET password_hash=?, reset_token=NULL, reset_expires=NULL 
                                             WHERE id=?');
                    $upd->bind_param('si', $hash, $user['id']);
                    if ($upd->execute()) {
                        $msg = '✅ Password set successfully. Redirecting to login...';
                        header("refresh:3;url=login.php");
                    } else {
                        $msg = '❌ Could not update password.';
                    }
                }
            }
        } else {
            $msg = '❌ Reset link expired.';
        }
    } else {
        $msg = '❌ Invalid reset token.';
    }
} else {
    $msg = '❌ No token provided.';
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Set Password</title>
  <style>
    body {display:flex;justify-content:center;align-items:center;height:100vh;background:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;}
    .box {background:#fff;padding:40px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);width:420px;text-align:center;}
    .box h2 {margin-bottom:20px;color:#2c3e50;}
    .box input,.box button {width:100%;padding:14px;margin:10px 0;font-size:16px;border-radius:4px;box-sizing:border-box;}
    .box input {border:1px solid #ccc;}
    .box button {background:#3498db;color:#fff;border:none;cursor:pointer;}
    .box button:hover {background:#2980b9;}
    .message {margin-bottom:15px;font-size:14px;}
    .link {color:#3498db;text-decoration:none;}
    .help {font-size:12px;color:#777;margin-top:8px;}
  </style>
</head>
<body>
  <div class="box">
    <h2>Set Password</h2>
    <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>

    <?php if ($valid): ?>
      <form method="POST" autocomplete="off">
        <input type="password" name="password" placeholder="New Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <button type="submit">Save Password</button>
        <p class="help">Minimum 6 characters. Avoid easy-to-guess words.</p>
      </form>
    <?php else: ?>
      <p><a href="forget_password.php" class="link">Request a new reset link</a></p>
    <?php endif; ?>

    <p><a href="login.php" class="link">Back to Login</a></p>
  </div>
</body>
</html>
