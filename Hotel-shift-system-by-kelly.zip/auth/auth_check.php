<?php
// Include this at the top of any protected page
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
