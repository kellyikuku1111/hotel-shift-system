<?php
require_once __DIR__ . '/../config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/PHPMailer/src/Exception.php';
require __DIR__ . '/../vendor/PHPMailer/src/PHPMailer.php';
require __DIR__ . '/../vendor/PHPMailer/src/SMTP.php';

session_start();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    $stmt = $conn->prepare("SELECT id, name FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 1) {
        $u = $res->fetch_assoc();

        // Generate token + expiry
        $reset_token   = bin2hex(random_bytes(16));
        $reset_expires = date("Y-m-d H:i:s", strtotime("+1 hour"));

        // Save token
        $update = $conn->prepare("UPDATE users SET reset_token=?, reset_expires=? WHERE id=?");
        $update->bind_param("ssi", $reset_token, $reset_expires, $u['id']);
        $update->execute();

        // Build correct reset link
        $reset_link = app_url('auth/reset_password.php') . '?token=' . urlencode($reset_token);

        // Send email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $smtp_host;
            $mail->SMTPAuth   = true;
            $mail->Username   = $smtp_user;
            $mail->Password   = $smtp_pass;
            $mail->SMTPSecure = $smtp_secure;
            $mail->Port       = $smtp_port;

            $mail->setFrom($smtp_from, $smtp_from_name);
            $mail->addAddress($email, $u['name']);
            $mail->isHTML(true);
            $mail->Subject = "Reset Your Password – $app_name";

            // Bulletproof table-based button
            $mail->Body = "
            <html>
              <body style='font-family:Segoe UI,Arial,sans-serif;background:#f4f6f9;padding:20px;'>
                <div style='max-width:600px;margin:auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.12);'>
                  <div style='background:#3498db;color:#fff;padding:16px;font-size:18px;font-weight:600;'>
                    $app_name
                  </div>
                  <div style='padding:24px;'>
                    <h2 style='margin:0 0 12px 0;color:#2c3e50;'>Hello, ".htmlspecialchars($u['name'])."</h2>
                    <p>We received a request to reset your password.</p>
                    <p style='text-align:center;'>
                      <table cellspacing='0' cellpadding='0'>
                        <tr>
                          <td align='center' bgcolor='#3498db' style='border-radius:6px;'>
                            <a href='$reset_link' target='_blank'
                               style='font-size:16px;font-family:Arial,sans-serif;color:#ffffff;
                                      text-decoration:none;padding:12px 20px;display:inline-block;'>
                              Reset Password
                            </a>
                          </td>
                        </tr>
                      </table>
                    </p>
                    <p style='color:#555;font-size:14px;'>This link will expire in 1 hour.</p>
                    <hr style='border:none;border-top:1px solid #eee;margin:20px 0;'>
                    <p style='font-size:13px;color:#777;'>If you didn’t request this, you can ignore this email.</p>
                  </div>
                </div>
              </body>
            </html>";

            $mail->AltBody = "Hello {$u['name']},\n\nReset your password here: $reset_link\n\nThis link expires in 1 hour.";

            $mail->send();
            $msg = "✅ If that email exists, a reset link has been sent.";
        } catch (Exception $e) {
            $msg = "❌ Could not send reset email. Error: {$mail->ErrorInfo}";
        }
    } else {
        // Don't reveal whether the email exists
        $msg = "✅ If that email exists, a reset link has been sent.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Forgot Password</title>
    <style>
        body {display:flex;justify-content:center;align-items:center;height:100vh;background:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;}
        .box {background:#fff;padding:40px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);width:400px;text-align:center;}
        .box h2 {margin-bottom:20px;color:#2c3e50;}
        .box input,.box button {width:100%;padding:14px;margin:10px 0;font-size:16px;border-radius:4px;box-sizing:border-box;}
        .box input {border:1px solid #ccc;}
        .box button {background:#3498db;color:#fff;border:none;cursor:pointer;}
        .box button:hover {background:#2980b9;}
        .message {margin-bottom:15px;font-size:14px;}
        .link {color:#3498db;text-decoration:none;}
    </style>
</head>
<body>
    <div class="box">
        <h2>Forgot Password</h2>
        <?php if ($msg): ?><p class="message"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
        <form method="POST">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button type="submit">Send Reset Link</button>
        </form>
        <p><a href="login.php" class="link">Back to Login</a></p>
    </div>
</body>
</html>
