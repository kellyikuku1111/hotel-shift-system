<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ' . dirname($_SERVER['PHP_SELF']) . '/login.php');
    exit;
}

require_once __DIR__ . '/../config.php';

if (!isset($_SESSION['role'])) {
    $stmt = $conn->prepare('SELECT role FROM users WHERE id=?');
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    if (!$user) {
        session_destroy();
        header('Location: login.php');
        exit;
    }
    $_SESSION['role'] = $user['role'];
}

function requireRole(array $roles) {
    if (!in_array($_SESSION['role'], $roles, true)) {
        http_response_code(403);
        die('🚫 Access denied.');
    }
}
