<?php
require_once __DIR__ . '/../config.php';
session_start();

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $pass  = $_POST['password'];

    $stmt = $conn->prepare('SELECT id, name, role, password_hash, is_verified FROM users WHERE email=?');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
if ($user && password_verify($pass, $user['password_hash'])) {
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['name'] = $user['name'];

   if ($user['role'] === 'admin' || $user['role'] === 'manager') {
    header('Location: ../admin/dashboard.php');
} else {
    header('Location: ../staff/dashboard.php'); // staff go here
}

}
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <style>
    body {display:flex;justify-content:center;align-items:center;height:100vh;background:#f4f6f9;font-family:Segoe UI,Arial,sans-serif;}
    .box {background:#fff;padding:40px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);width:360px;text-align:center;}
    .box h2 {margin-bottom:20px;color:#2c3e50;}
    .box input,.box button {width:100%;padding:14px;margin:10px 0;font-size:16px;border-radius:4px;box-sizing:border-box;}
    .box input {border:1px solid #ccc;}
    .box button {background:#3498db;color:#fff;border:none;cursor:pointer;}
    .box button:hover {background:#2980b9;}
    .message {margin-bottom:15px;font-size:14px;}
  </style>
</head>
<body>
  <div class="box">
    <h2>Login</h2>
    <?php if ($msg): ?><p class="message"><?= $msg ?></p><?php endif; ?>
   <form method="POST">
    <input type="email" name="email" placeholder="Email Address" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
</form>

<p><a href="forgot_password.php" class="link">Forgot your password?</a></p>

  </div>
</body>
</html>
