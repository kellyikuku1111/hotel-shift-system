-- Create database
CREATE DATABASE IF NOT EXISTS hotel_shifts;
USE hotel_shifts;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','manager','staff') NOT NULL DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Shifts table (templates)
CREATE TABLE shifts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL
);

-- Assignments table (who works which shift on which date)
CREATE TABLE assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    shift_id INT NOT NULL,
    work_date DATE NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (shift_id) REFERENCES shifts(id) ON DELETE CASCADE
);

-- Leave requests
CREATE TABLE leave_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT,
    status ENUM('pending','approved','denied') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Shift swaps
CREATE TABLE shift_swaps (
    id INT AUTO_INCREMENT PRIMARY KEY,
    requester_id INT NOT NULL,
    target_id INT NOT NULL,
    shift_id INT NOT NULL,
    swap_date DATE NOT NULL,
    status ENUM('pending','approved','denied') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (target_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (shift_id) REFERENCES shifts(id) ON DELETE CASCADE
);

-- Notifications
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message VARCHAR(255) NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Staff availability (preferences)
CREATE TABLE availability (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'),
    available_start TIME,
    available_end TIME,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert demo users
INSERT INTO users (name, email, password, role) VALUES
('Admin User', 'admin@example.com', MD5('admin123'), 'admin'),
('Manager User', 'manager@example.com', MD5('manager123'), 'manager'),
('Staff User', 'staff@example.com', MD5('staff123'), 'staff');

-- Insert demo shifts
INSERT INTO shifts (name, start_time, end_time) VALUES
('Morning', '08:00:00', '14:00:00'),
('Afternoon', '14:00:00', '20:00:00'),
('Night', '20:00:00', '02:00:00');

-- Sample assignments
INSERT INTO assignments (user_id, shift_id, work_date) VALUES
(3, 1, CURDATE()), -- Staff User on Morning shift today
(3, 2, DATE_ADD(CURDATE(), INTERVAL 1 DAY)), -- Tomorrow Afternoon
(3, 3, DATE_ADD(CURDATE(), INTERVAL 2 DAY)); -- Day after tomorrow Night

-- Sample leave requests
INSERT INTO leave_requests (user_id, start_date, end_date, reason, status) VALUES
(3, DATE_ADD(CURDATE(), INTERVAL 3 DAY), DATE_ADD(CURDATE(), INTERVAL 4 DAY), 'Family event', 'pending'),
(3, DATE_ADD(CURDATE(), INTERVAL 7 DAY), DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'Medical appointment', 'approved');

-- Sample shift swaps
INSERT INTO shift_swaps (requester_id, target_id, shift_id, swap_date, status) VALUES
(3, 2, 1, DATE_ADD(CURDATE(), INTERVAL 5 DAY), 'pending');

-- Sample notifications
INSERT INTO notifications (user_id, message, is_read) VALUES
(3, 'Your leave request is pending approval.', 0),
(3, 'Shift swap request submitted.', 0),
(2, 'New leave request requires your review.', 0),
(1, 'System report generated successfully.', 0);
